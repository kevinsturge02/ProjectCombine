# Shell

This is a working basic shell for external unix commands like ls and grep
Supports internal commands like cd, exit, jobs, and echo
Supports up to two piped commands
Supports redirection of input and output with < and >
Allows for background processing using &
Expands arguments using ~ for home and $ for enviromental vars

## Group Members
- **Grant Gibson**: gjg23@fsu.edu
- **Kevin Sturge**: kms21c@fsu.edu
- **Nate Longberry**: njl20a@fsu.edu
## Division of Labor

### Division of Labor 

### Part 1: Prompt
- **Responsibilities**: command prompt indicating the user and working directory
- **Assigned to**: Grant, Kevin
- **Completed by**: Grant, Kevin

### Part 2: Environment Variables
- **Responsibilities**: expansion of enviromental variables using $
- **Assigned to**: Grant, Kevin
- **Completed by**: Grant, Kevin

### Part 3: Tilde Expansion
- **Responsibilities**: expansion of ~ to the home directory
- **Assigned to**: Grant, Nate
- **Completed by**: Grant, Kevin

### Part 4: $PATH Search
- **Responsibilities**: Search through directoy specified in $PATH
- **Assigned to**: Kevin, Nate
- **Completed by**: Grant, Kevin

### Part 5: External Command Execution
- **Responsibilities**: use fork and execv to execute external unix commands
- **Assigned to**: Kevin, Nate
- **Completed by**: Kevin

### Part 6: I/O Redirection
- **Responsibilities**: allow a command to recive input from a file and write output to a file
- **Assigned to**: Nate, Grant
- **Completed by**: Kevin, Grant

### Part 7: Piping
- **Responsibilities**: allow for simultaneous execution of multiple commands with input and outputs interconnected
- **Assigned to**: Kevin, Grant
- **Completed by**: Kevin, Grant

### Part 8: Background Processing
- **Responsibilities**: Allow processes to run in the background concurrently
- **Assigned to**: Kevin, Nate
- **Completed by**: Grant

### Part 9: Internal Command Execution
- **Responsibilities**: implement shell function for commands exit, cd, and jobs
- **Assigned to**: Grant, Nate
- **Completed by**: Kevin, Grant

### Extra Credit
- **Responsibilities**: none assigned
- **Assigned to**: none

## File Listing
```
shell/
│
├── src/
│ ├── main.c
│ ├── commander.c
│ ├── lexer.c
│ ├── path_search.c
│ ├── prompt.c
│ ├── shell.c
│ ├── job_handler.c
│
├── include/
│ ├── commander.h
│ ├── lexer.h
│ ├── path_search.h
│ ├── prompt.h
│ ├── shell.h
│ ├── job_handler.h
│
├── README.md
└── Makefile
```
## How to Compile & Execute

### Requirements
- **Compiler**: `gcc` for C/C++

### Compilation
```bash
make
```
This will build the executable in bin
### Execution
```bash
make run
```
alternatively, after a compiling with make you can run ./bin/shell to run the program

This will run the program ...

## Bugs
- **Bug 1**: None

## Extra Credit
- **Extra Credit 1**: Shell-ception: able to run inside itself
