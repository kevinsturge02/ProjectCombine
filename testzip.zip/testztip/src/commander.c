// commander.c
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include "path_search.h" 
#include "commander.h"
#include "prompt.h"
#include "job_handler.h"

int built_in(tokenlist *tokens) {
    if (tokens->size == 0) return 1;  

    if (strcmp(tokens->items[0], "cd") == 0) {
        char *target;
        if (tokens->size < 2) {
            target = getenv("HOME");
            if (!target) {
                fprintf(stderr, "cd: HOME not set\n");
                return 1;
            }
        } else {
            target = tokens->items[1];
        }
        if (chdir(target) != 0) {
            perror("cd failed");
        }
        return 1;
    }

    // Builtin echo with redirection
    if (strcmp(tokens->items[0], "echo") == 0) {
        int redirectPos = -1;
        int outputFd = STDOUT_FILENO;
        for (int i = 1; i < tokens->size; i++) {
            if (strcmp(tokens->items[i], ">") == 0 || strcmp(tokens->items[i], ">>") == 0) {
                redirectPos = i;
                if (i + 1 < tokens->size) {
                    int flags = 0;
                    if (strcmp(tokens->items[i], ">") == 0) {
                        flags = O_WRONLY | O_CREAT | O_TRUNC;
                    } else {
                        flags = O_WRONLY | O_CREAT | O_APPEND;
                    }
                    outputFd = open(tokens->items[i+1], flags, 0644);
                    if (outputFd == -1) {
                        perror("echo: error opening output file");
                        return 1;
                    }
                } else {
                    fprintf(stderr, "echo: no output file specified.\n");
                    return 1;
                }
                break;
            }
        }

        for (int i = 1; i < tokens->size && (redirectPos == -1 || i < redirectPos); i++) {
            write(outputFd, tokens->items[i], strlen(tokens->items[i]));
            if (i + 1 < tokens->size && (redirectPos == -1 || i + 1 < redirectPos)) {
                write(outputFd, " ", 1);
            }
        }
        write(outputFd, "\n", 1);

        if (outputFd != STDOUT_FILENO) {
            close(outputFd);
        }
        return 1;
    }

    // Built-in jobs
    if (strcmp(tokens->items[0], "jobs") == 0) {
        if (tokens->size > 1) {
            fprintf(stderr, "jobs: too many arguments\n");
            return 1;
        }
        list_jobs();
        return 1;
    }

    // Built-in exit
    if (strcmp(tokens->items[0], "exit") == 0) {
        wait_all_jobs();
        printf("Exiting shell...\n");
        exit(0);
    }

    return 0;  
}

void execute_commands(tokenlist *tokens) {
    if (tokens->size == 0) return;

    int background = 0;
    char* command_line = NULL;

    // Check for background operator
    if (tokens->size > 0 && strcmp(tokens->items[tokens->size-1], "&") == 0) {
        background = 1;
        tokens->size--;
    }

    // Generate command line for background jobs
    if (background) {
        size_t len = 0;
        for (int i = 0; i < tokens->size; i++) {
            len += strlen(tokens->items[i]) + 1;
        }
        command_line = malloc(len);
        if (!command_line) {
            perror("malloc failed");
            return;
        }
        char* ptr = command_line;
        for (int i = 0; i < tokens->size; i++) {
            const char *token = tokens->items[i];
            while (*token != '\0') {
                *ptr++ = *token++;
            }
            // Add space if not last token
            if (i < tokens->size - 1) {
                *ptr++ = ' ';
            }
        }
        *ptr = '\0';
    }

    // Check for pipes
    int has_pipe = 0;
    for (int i = 0; i < tokens->size; i++) {
        if (strcmp(tokens->items[i], "|") == 0) {
            has_pipe = 1;
            break;
        }
    }

    if (has_pipe) {
        execute_piped_commands(tokens, command_line, background);
        if (command_line) free(command_line); // Free command_line if not used
        return;
    }

    if (built_in(tokens)) {
        if (command_line) free(command_line);
        return;
    }

    char *cmd_path = findCommandPath(tokens->items[0]);
    if (!cmd_path) {
        fprintf(stderr, "%s: command not found\n", tokens->items[0]);
        if (command_line) free(command_line);
        return;
    }

    int input_fd = -1, output_fd = -1;
    int arg_index = 0;
    char **args = malloc((tokens->size + 1) * sizeof(char *));
    if (!args) {
        perror("malloc failed");
        free(cmd_path);
        if (command_line) free(command_line);
        return;
    }

    for (int i = 0; i < tokens->size; i++) {
        if (strcmp(tokens->items[i], "<") == 0) {
            if (i + 1 >= tokens->size) {
                fprintf(stderr, "Error: No input file specified.\n");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            input_fd = open(tokens->items[i + 1], O_RDONLY);
            if (input_fd < 0) {
                perror("Error opening input file");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            i++;
        } else if (strcmp(tokens->items[i], ">") == 0) {
            if (i + 1 >= tokens->size) {
                fprintf(stderr, "Error: No output file specified.\n");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            output_fd = open(tokens->items[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (output_fd < 0) {
                perror("Error opening output file");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            i++;
        } else if (strcmp(tokens->items[i], ">>") == 0) {
            if (i + 1 >= tokens->size) {
                fprintf(stderr, "Error: No output file specified.\n");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            output_fd = open(tokens->items[i + 1], O_WRONLY | O_CREAT | O_APPEND, 0644);
            if (output_fd < 0) {
                perror("Error opening output file");
                free(cmd_path);
                free(args);
                if (command_line) free(command_line);
                return;
            }
            i++;
        } else {
            args[arg_index++] = tokens->items[i];
        }
    }
    args[arg_index] = NULL;

    pid_t pid = fork();
    if (pid == 0) {
        if (input_fd != -1) {
            dup2(input_fd, STDIN_FILENO);
            close(input_fd);
        }
        if (output_fd != -1) {
            dup2(output_fd, STDOUT_FILENO);
            close(output_fd);
        }

        execv(cmd_path, args);
        perror("execv failed");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        if (background) {
            add_job(pid, command_line);
        } else {
            waitpid(pid, NULL, 0);
        }
    } else {
        perror("fork failed");
    }

    if (command_line) free(command_line);
    free(cmd_path);
    free(args);
    if (input_fd != -1) close(input_fd);
    if (output_fd != -1) close(output_fd);
}

tokenlist* create_subtokens(tokenlist* tokens, int start, int end) {
    tokenlist* sub = new_tokenlist();
    for (int i = start; i < end; i++) {
        add_token(sub, tokens->items[i]);
    }
    return sub;
}

void execute_piped_commands(tokenlist* tokens, const char* command_line, int background) {
    int pipecount = 0;
    for (int i = 0; i < tokens->size; i++) {
        if (strcmp(tokens->items[i], "|") == 0) {
            pipecount++;
        }
    }

    if (pipecount > 2) {
        fprintf(stderr, "Error: Maximum number of pipes supported is 2.\n");
        return;
    }

    int num_cmds = pipecount + 1;
    tokenlist** cmds = malloc(num_cmds * sizeof(tokenlist*));
    if (!cmds) {
        perror("malloc failed");
        return;
    }

    int cmd_start = 0;
    int cmd_index = 0;
    for (int i = 0; i <= tokens->size; i++) {
        if (i == tokens->size || (i < tokens->size && strcmp(tokens->items[i], "|") == 0)) {
            cmds[cmd_index] = create_subtokens(tokens, cmd_start, i);
            cmd_index++;
            cmd_start = i + 1;
        }
    }

    char* input_file = NULL;
    char* output_file = NULL;
    int append = 0;

    // First command redirection with manual string copy
    for (int i = 0; i < cmds[0]->size; i++) {
        if (strcmp(cmds[0]->items[i], "<") == 0) {
            if (i + 1 < cmds[0]->size) {
                // Manual strlen calculation
                const char* src = cmds[0]->items[i+1];
                size_t len = 0;
                while (src[len] != '\0') len++;
                
                input_file = malloc(len + 1);
                if (!input_file) {
                    perror("malloc failed");
                    return;
                }
                
                // Manual strcpy replacement
                for (size_t j = 0; j <= len; j++) {
                    input_file[j] = src[j];
                }

                tokenlist* new_cmd = new_tokenlist();
                for (int j = 0; j < cmds[0]->size; j++) {
                    if (j == i || j == i + 1) continue;
                    add_token(new_cmd, cmds[0]->items[j]);
                }
                free_tokens(cmds[0]);
                cmds[0] = new_cmd;
            } else {
                fprintf(stderr, "Error: No input file specified.\n");
                return;
            }
            break;
        }
    }

    // Last command redirection with manual string copy
    for (int i = 0; i < cmds[num_cmds - 1]->size; i++) {
        if (strcmp(cmds[num_cmds - 1]->items[i], ">") == 0 || 
            strcmp(cmds[num_cmds - 1]->items[i], ">>") == 0) {
            if (i + 1 < cmds[num_cmds - 1]->size) {
                // Manual strlen calculation
                const char* src = cmds[num_cmds - 1]->items[i+1];
                size_t len = 0;
                while (src[len] != '\0') len++;
                
                output_file = malloc(len + 1);
                if (!output_file) {
                    perror("malloc failed");
                    return;
                }
                
                // Manual strcpy replacement
                for (size_t j = 0; j <= len; j++) {
                    output_file[j] = src[j];
                }

                if (strcmp(cmds[num_cmds-1]->items[i], ">>") == 0) {
                    append = 1;
                }
                tokenlist *new_cmd = new_tokenlist();
                for (int j = 0; j < cmds[num_cmds - 1]->size; j++) {
                    if (j == i || j == i+1) continue;
                    add_token(new_cmd, cmds[num_cmds - 1]->items[j]);
                }
                free_tokens(cmds[num_cmds - 1]);
                cmds[num_cmds - 1] = new_cmd;
            } else {
                fprintf(stderr, "Error: No output file specified.\n");
                return;
            }
            break;
        }
    }

    int num_pipes = num_cmds - 1;
    int pipes[num_pipes][2];
    for (int i = 0; i < num_pipes; i++) {
        if (pipe(pipes[i]) < 0) {
            perror("pipe failed");
            return;
        }
    }

    pid_t pids[num_cmds];
    for (int i = 0; i < num_cmds; i++) {
        pids[i] = fork();
        if (pids[i] == 0) {
            if (i == 0) {
                // First command handling
                if (input_file) {
                    int in_fd = open(input_file, O_RDONLY);
                    if (in_fd < 0) {
                        perror("Error opening input file");
                        exit(EXIT_FAILURE);
                    }
                    dup2(in_fd, STDIN_FILENO);
                    close(in_fd);
                }
                if (num_pipes > 0) {
                    dup2(pipes[i][1], STDOUT_FILENO);
                }
            } else if (i == num_cmds - 1) {
                // Last command with proper append handling
                dup2(pipes[i - 1][0], STDIN_FILENO);
                if (output_file) {
                    int flags = O_WRONLY | O_CREAT;
                    flags |= append ? O_APPEND : O_TRUNC;
                    int out_fd = open(output_file, flags, 0644);
                    if (out_fd < 0) {
                        perror("Error opening output file");
                        exit(EXIT_FAILURE);
                    }
                    dup2(out_fd, STDOUT_FILENO);
                    close(out_fd);
                }
            } else {
                // Middle commands
                dup2(pipes[i-1][0], STDIN_FILENO);
                dup2(pipes[i][1], STDOUT_FILENO);
            }

            // Close all pipe ends
            for (int j = 0; j < num_pipes; j++) {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }

            // Command execution
            char* cmd_path = findCommandPath(cmds[i]->items[0]);
            if (!cmd_path) {
                fprintf(stderr, "%s: command not found\n", cmds[i]->items[0]);
                exit(EXIT_FAILURE);
            }
            
            // Prepare arguments
            char** args = malloc((cmds[i]->size + 1) * sizeof(char*));
            for (int j = 0; j < cmds[i]->size; j++) {
                args[j] = cmds[i]->items[j];
            }
            args[cmds[i]->size] = NULL;

            execv(cmd_path, args);
            perror("execv failed");
            exit(EXIT_FAILURE);
        } else if (pids[i] < 0) {
            perror("fork failed");
            return;
        }
    }

    // Parent cleanup
    for (int i = 0; i < num_pipes; i++) {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }

    // Job tracking
    if (background) {
        add_job(pids[num_cmds - 1], command_line);
    } else {
        for (int i = 0; i < num_cmds; i++) {
            waitpid(pids[i], NULL, 0);
        }
    }

    // Memory cleanup
    if (input_file) free(input_file);
    if (output_file) free(output_file);
    for (int i = 0; i < num_cmds; i++) {
        free_tokens(cmds[i]);
    }
    free(cmds);
}
