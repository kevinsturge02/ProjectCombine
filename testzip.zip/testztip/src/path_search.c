// path_search.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include "path_search.h"

int hasSlash(const char* command) {
    return strchr(command, '/') != NULL;
}

int isExecutable(const char* path) {
    struct stat st;
    return (stat(path, &st) == 0 && 
            S_ISREG(st.st_mode) && 
            (st.st_mode & S_IXUSR)) ? 1 : 0;
}

char *my_strdup(const char *s) {
    size_t len = strlen(s) + 1;
    char *dup = malloc(len);
    if (dup) {
        memcpy(dup, s, len);
    }
    return dup;
}

char* findCommandPath(const char* command) {
    if (hasSlash(command)) {
        return isExecutable(command) ? my_strdup(command) : NULL;
    }

    char* path_env = getenv("PATH");
    if (!path_env) return NULL;

    char* path_copy = my_strdup(path_env);
    if (!path_copy) return NULL;

    char* dir = strtok(path_copy, ":");
    char* result = NULL;
    char full_path[4096];

    while (dir && !result) {
        snprintf(full_path, sizeof(full_path), "%s/%s", dir, command);
        if (isExecutable(full_path)) {
            result = my_strdup(full_path);
        }
        dir = strtok(NULL, ":");
    }

    free(path_copy);
    return result;
}
