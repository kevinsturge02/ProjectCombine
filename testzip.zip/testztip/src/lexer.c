//lexer.c

#include "lexer.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *get_input(void) {
	char *buffer = NULL;
	int bufsize = 0;
	char line[5];
	while (fgets(line, 5, stdin) != NULL)
	{
		int addby = 0;
		char *newln = strchr(line, '\n');
		if (newln != NULL)
			addby = newln - line;
		else
			addby = 5 - 1;
		buffer = (char *)realloc(buffer, bufsize + addby);
		memcpy(&buffer[bufsize], line, addby);
		bufsize += addby;
		if (newln != NULL)
			break;
	}
	buffer = (char *)realloc(buffer, bufsize + 1);
	buffer[bufsize] = 0;
	return buffer;
}

tokenlist *new_tokenlist(void) {
	tokenlist *tokens = (tokenlist *)malloc(sizeof(tokenlist));
	tokens->size = 0;
	tokens->items = (char **)malloc(sizeof(char *));
	tokens->items[0] = NULL; /* make NULL terminated */
	return tokens;
}

void add_token(tokenlist *tokens, char *item) {
	int i = tokens->size;

	// if first part of token is $ then get envar but expand for ~
	if (item[0] == '$') {
		char *env_name = item + 1; // skip $
		char *envar = getenv(env_name);

        if (envar) {
            item = envar;
        } else {
            item = "";
        }
	}
	// perform tilda expansion
	else if (item[0] == '~') {
		char *home = getenv("HOME");
        if (!home) home = "";

        // if only ~
        if (strlen(item) == 1) {
            item = home;
        }
        // if ~/something
        else if (item[1] == '/') {
			size_t home_len = strlen(home);
			size_t rest_len = strlen(item+1);
			size_t new_size = home_len + rest_len + 1;

			char* new_item = (char *)malloc(new_size);
			strcpy(new_item, home);
			strcat(new_item, item+1);

			item = new_item;
        }
	}

	tokens->items = (char **)realloc(tokens->items, (i + 2) * sizeof(char *));
	tokens->items[i] = (char *)malloc(strlen(item) + 1);
	tokens->items[i + 1] = NULL;
	strcpy(tokens->items[i], item);

	tokens->size += 1;
} 

tokenlist *get_tokens(char *input) {
	char *buf = (char *)malloc(strlen(input) + 1);
	strcpy(buf, input);
	tokenlist *tokens = new_tokenlist();
	char *tok = strtok(buf, " ");
	while (tok != NULL)
	{
		add_token(tokens, tok);
		tok = strtok(NULL, " ");
	}
	free(buf);
	return tokens;
}

void free_tokens(tokenlist *tokens) {
	for (int i = 0; i < tokens->size; i++)
		free(tokens->items[i]);
	free(tokens->items);
	free(tokens);
}

void print_tokens(tokenlist *tokens) {
	if (!tokens || !tokens->items) return;

	for (size_t i = 0; i < tokens->size; i++) {
		printf("Token[%zu] : %s\n", i, tokens->items[i]);
	}
}
