// job_handler.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include "job_handler.h"

#define MAX_JOBS 10

typedef struct {
    int job_number;
    int pid;
    char* command_line;
} Job;

static Job jobs[MAX_JOBS];
static int next_job_number = 1;

void add_job(int pid, const char* command_line) {
    for (int i = 0; i < MAX_JOBS; i++) {
        if (jobs[i].pid == 0) {
            size_t len = 0;
            while (command_line[len] != '\0') {
                len++;
            }
            
            jobs[i].command_line = malloc(len + 1);
            if (!jobs[i].command_line) {
                perror("malloc failed");
                return;
            }
            
            for (size_t j = 0; j <= len; j++) {
                jobs[i].command_line[j] = command_line[j];
            }
            
            jobs[i].job_number = next_job_number++;
            jobs[i].pid = pid;
            printf("[%d] %d\n", jobs[i].job_number, pid);
            return;
        }
    }
    fprintf(stderr, "Max background jobs reached.\n");
}

void check_jobs(void) {
    for (int i = 0; i < MAX_JOBS; i++) {
        if (jobs[i].pid != 0) {
            int status;
            pid_t result = waitpid(jobs[i].pid, &status, WNOHANG);
            if (result > 0) {
                printf("[%d] + done %s\n", jobs[i].job_number, jobs[i].command_line);
                free(jobs[i].command_line);
                jobs[i].pid = 0;
            } else if (result < 0) {
                perror("waitpid failed");
            }
        }
    }
}

void list_jobs(void) {
    int active_jobs = 0;
    int max_job_number = 0;

    // Find the highest job number
    for (int i = 0; i < MAX_JOBS; i++) {
        if (jobs[i].pid != 0 && jobs[i].job_number > max_job_number) {
            max_job_number = jobs[i].job_number;
        }
    }

    // Print active jobs
    for (int i = 0; i < MAX_JOBS; i++) {
        if (jobs[i].pid != 0) {
            printf("[%d]%c %d %s\n",
                   jobs[i].job_number,
                   (jobs[i].job_number == max_job_number) ? '+' : ' ',
                   jobs[i].pid,
                   jobs[i].command_line);
            active_jobs++;
        }
    }

    if (active_jobs == 0) {
        printf("No active background jobs.\n");
    }
}

void wait_all_jobs(void) {
    for (int i = 0; i < MAX_JOBS; i++) {
        if (jobs[i].pid != 0) {
            waitpid(jobs[i].pid, NULL, 0); // Wait for the job
            free(jobs[i].command_line);
            jobs[i].pid = 0; // Mark as inactive
        }
    }
}