// prompt.c


#define _POSIX_C_SOURCE 200112L


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include "prompt.h"


char *get_user() {
    char *user = getenv("USER");
    if (!user) user = "unknown";
    return user;
}

char *get_machine() {
    
    long host_name_max = sysconf(_SC_HOST_NAME_MAX);
    if (host_name_max == -1) host_name_max = 225; 

    
    char *machine = malloc(host_name_max + 1);
    if (!machine) {
        fprintf(stderr, "malloc failed for host machine name.\n");
        return NULL;
    }

    if (gethostname(machine, host_name_max) == 0) {
        machine[host_name_max] = '\0'; 
    } else {
        snprintf(machine, host_name_max + 1, "%s", "unknown"); 
    }
    return machine;
}

char *get_pwd() {
    char *buffer = malloc(PWD_SIZE + 1);
    if (buffer) {
        if (getcwd(buffer, PWD_SIZE) == NULL) {
            perror("getcwd failed");
            free(buffer);
            return NULL;
        }
    }
    
    return buffer;
}

void display_prompt(char *user, char *machine, char *pwd) {
    printf("%s@%s:%s> ", user, machine, pwd);
    fflush(stdout);
}