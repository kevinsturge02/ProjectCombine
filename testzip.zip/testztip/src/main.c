//main.c
#include "shell.h"

int main() {
    shell_loop();
    return 0;
}