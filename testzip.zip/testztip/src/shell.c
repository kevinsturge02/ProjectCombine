// Shell.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "shell.h"
#include "lexer.h"
#include "prompt.h"
#include "commander.h"
#include "job_handler.h"

void shell_loop() {
    
    char *user = get_user();
    char *machine = get_machine();
    char *pwd = get_pwd();
    
    while(1) {
       
        pwd = get_pwd();

        display_prompt(user, machine, pwd);
        
        
        char *input = get_input();
        tokenlist *tokens = get_tokens(input);

        
        if (tokens->size > 0 && strcmp(tokens->items[0], "exit") == 0) {
            free(input);
            free_tokens(tokens);
            break;
        }

      
        if (!built_in(tokens)) {
            execute_commands(tokens);
        }

        check_jobs();

        free(pwd);

        free(input);
        free_tokens(tokens);
    }

   
    free(pwd);
    free(machine);
}