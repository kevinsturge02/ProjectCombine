#ifndef PATH_SEARCH_H
#define PATH_SEARCH_H

#include "lexer.h"

int hasSlash(const char* command);


int isExecutable(const char* path);


char* findCommandPath(const char* command);

#endif 
