//shell.h
#ifndef SHELL_H
#define SHELL_H

void display_prompt();
void shell_loop();

#endif