//prompt.h

#define PWD_SIZE 1024 //working directory size

char *get_user();
char *get_machine();
char *get_pwd();
void display_prompt(char *user, char *machine, char *pwd);