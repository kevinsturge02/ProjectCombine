// job_handler.h
#ifndef JOB_HANDLER_H
#define JOB_HANDLER_H

void add_job(int pid, const char* command_line);
void check_jobs(void);
void list_jobs(void);
void wait_all_jobs(void);

#endif