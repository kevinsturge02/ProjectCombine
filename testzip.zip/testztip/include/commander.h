// commander.h

#include "lexer.h"

int built_in(tokenlist *tokens);
void execute_commands(tokenlist *tokens);
tokenlist* create_subtokens(tokenlist* tokens, int start, int end);
void execute_piped_commands(tokenlist* tokens, const char* command_line, int background);